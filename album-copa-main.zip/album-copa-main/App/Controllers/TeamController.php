<?php

namespace App\Controllers;

use Slim\Http\Request;
use Slim\Http\Response;
use App\Repositories\TeamRepository;

class TeamController {

    private $repository;

    public function __construct()
    {
        $this->repository = new TeamRepository();
    }

    public function getAll(Request $request, Response $response, array $args){
        
        $teams = $this->repository->getAll();

        return $response->withJson($teams)->withStatus(200);
    }

    public function getById(Request $request, Response $response, array $args){
        
        $id = $args['id'];

        $teams = $this->repository->getById($id);
        return $response->withJson($teams)->withStatus(200);
    }

     public function getByName(Request $request, Response $response, array $args){

        $name = $args['nome'];
        
        $team = $this->repository->getByName($name);
        return $response->withJson($team)->withStatus(200);
    }

    public function getByGroup(Request $request, Response $response, array $args){

        $grupo = $args["grupo"];
        
        $teams = $this->repository->getByGroup($grupo);
        return $response->withJson($teams)->withStatus(200);
    }

    public function create(Request $request, Response $response, array $args){

        //Obter campo por campo
        //$data = $request->getParam('nome_do_campo');

        //Obter todos os campos do formulario
        //$data = $request->getParams();
        
        //obter todos os dados de envio
        $data = $request->getParsedBody();

        $data['id'] = $this->repository->create($data['texto']);

        return $response->withJson(["id" => $data]);

    }



}