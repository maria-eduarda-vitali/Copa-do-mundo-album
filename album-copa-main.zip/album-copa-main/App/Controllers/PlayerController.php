<?php

namespace App\Controllers;

use Slim\Http\Request;
use Slim\Http\Response;
use App\Repositories\PlayerRepository;

class PlayerController {

    private $repository;

    public function __construct()
    {
        $this->repository = new PlayerRepository();
    }

    public function getAll(Request $request, Response $response, array $args){
        
        $players = $this->repository->getAll();

        return $response->withJson($players)->withStatus(200);
    }

    public function getSelecoes(Request $request, Response $response, array $args){
        
        $time = $args['selecoes'];

        $players = $this->repository->getSelecoes($time);
        return $response->withJson($players)->withStatus(200);
    }


    public function getById(Request $request, Response $response, array $args){
        
        $id = $args['id'];

        $players = $this->repository->getById($id);
        return $response->withJson($players)->withStatus(200);
    }

     public function getByNamePlayer(Request $request, Response $response, array $args){

        $name = $args['nome'];
        
        $players = $this->repository->getByNamePlayer($name);
        return $response->withJson($players)->withStatus(200);
    }

    public function getByPosicao(Request $request, Response $response, array $args){

        $pos = $args["pos"];
        
        $players = $this->repository->getByPosicao($pos);
        return $response->withJson($players)->withStatus(200);
    }



}