<?php 

namespace App\Repositories;

use App\Connection\ConnectionFactory;
use PDO;

class PlayerRepository {

    public $connection;

    public function __construct()
    {
        $factory = new ConnectionFactory();
        $this->connection = $factory->getConnection();
    }

    public function getAll(){
        $sql = "SELECT * FROM tb_players";

        $table = $this->connection->query($sql); 
        return $table->fetchAll(PDO::FETCH_ASSOC);

    }

    public function getSelecoes(){
        $sql = "SELECT * FROM tb_players WHERE tb_players.team_code = 'BRA'";

        $table = $this->connection->query($sql); 
        return $table->fetchAll(PDO::FETCH_ASSOC);

    }

    public function getByPosicao(string $pos){
        $sql = "SELECT * FROM tb_players WHERE tb_players.position = :position";

        $table = $this->connection->prepare($sql); 
        $table->bindParam(":position", $pos);

        $table->execute();

        $resultados = $table->fetchAll(PDO::FETCH_ASSOC);

        return $resultados;
    }

    public function getByNamePlayer(string $nome){
        $sql = "SELECT * FROM tb_players WHERE player LIKE :players";

        $table = $this->connection->prepare($sql); 
        $table->bindValue(":players", "%".$nome."%");
        $table->bindParam(":players", $nome);

        $table->execute();

        $resultados = $table->fetchAll(PDO::FETCH_ASSOC);

        return $resultados;
    }

    public function getById($id){
        $sql = "SELECT * FROM tb_players WHERE id = :id";

        $table = $this->connection->prepare($sql); 
        $table->bindParam(":id", $id);

        $table->execute();

        $resultados = $table->fetch(PDO::FETCH_ASSOC);

        return $resultados;
    }
}